#!/usr/bin/env python3
"""
🔥 GPU-ACCELERATED BRUTE FORCE FOR GSMG 5 BTC PUZZLE k1 & k2 EXTRACTION
Target: P100/P1000 GPU (NVIDIA CUDA)

Uses numba.cuda for GPU acceleration + CPU fallback
Tests all permutations of 10 letters mapping to Base58 alphabet
Verifies Base58Check checksums for valid WIF keys

USAGE:
  python3 gpu_brute_force_final.py

REQUIREMENTS:
  pip install numba numpy
  CUDA Toolkit installed
  NVIDIA GPU with CUDA support
"""

import hashlib
import itertools
import time
import sys
from typing import Tuple, Optional, Dict, List

try:
    from numba import cuda, jit
    HAS_CUDA = True
except ImportError:
    HAS_CUDA = False
    print("⚠️  WARNING: numba not available - using CPU-only mode")
    print("   Install: pip install numba")

# ============================================================================
# CONSTANTS
# ============================================================================

BASE58 = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"
CUSTOM_ALPHABET = "abcdefghio"

SECTION2 = "agdafaoaheiecggchgicbbhcgbehcfcoabicfdhhcdbbcagbdaiobbgbeadeddecfobfdhgdobdgooiigdocdaoofidh"
SECTION3 = "cfobfdhgdobdgooiigdocdaoofidh"

# ============================================================================
# CORE FUNCTIONS
# ============================================================================

def base58_decode_check(wif: str) -> Tuple[bool, Optional[bytes]]:
    """Decode Base58Check and verify checksum"""
    try:
        if not wif or len(wif) < 10:
            return False, None
        
        # Decode Base58 to integer
        decoded = 0
        for char in wif:
            if char not in BASE58:
                return False, None
            decoded = decoded * 58 + BASE58.index(char)
        
        # Convert to bytes
        hex_str = hex(decoded)[2:]
        if len(hex_str) % 2:
            hex_str = '0' + hex_str
        data = bytes.fromhex(hex_str)
        
        # Add leading zeros for leading '1's
        num_leading = len(wif) - len(wif.lstrip('1'))
        data = b'\x00' * num_leading + data
        
        if len(data) < 5:
            return False, None
        
        # Verify checksum
        payload = data[:-4]
        checksum = data[-4:]
        
        hash1 = hashlib.sha256(payload).digest()
        hash2 = hashlib.sha256(hash1).digest()
        computed = hash2[:4]
        
        is_valid = (checksum == computed)
        return is_valid, payload if is_valid else None
        
    except Exception:
        return False, None


def apply_mapping(text: str, mapping: Dict[str, str]) -> str:
    """Apply character mapping"""
    return ''.join(mapping.get(c, c) for c in text)


def test_permutation(perm: Tuple[str, ...]) -> Optional[Dict]:
    """Test a single permutation"""
    mapping = dict(zip(CUSTOM_ALPHABET, perm))
    
    k1 = apply_mapping(SECTION2, mapping)
    k2 = apply_mapping(SECTION3, mapping)
    
    result = {
        'mapping': mapping,
        'k1': k1,
        'k2': k2,
        'k1_valid': False,
        'k2_valid': False,
    }
    
    # Check k1
    if len(k1) == 51 and k1[0] == '5' and all(c in BASE58 for c in k1):
        valid, payload = base58_decode_check(k1)
        if valid:
            result['k1_valid'] = True
    
    # Check k2
    if len(k2) == 52 and k2[0] in 'KL' and all(c in BASE58 for c in k2):
        valid, payload = base58_decode_check(k2)
        if valid:
            result['k2_valid'] = True
    
    return result


# ============================================================================
# BRUTE FORCE IMPLEMENTATION
# ============================================================================

def brute_force_search() -> List[Dict]:
    """Main brute force search - tests all 10! permutations"""
    
    print("="*80)
    print("🔥 GPU BRUTE FORCE: k1 & k2 EXTRACTION FOR GSMG 5 BTC PUZZLE")
    print("="*80)
    print()
    
    # Check GPU
    if HAS_CUDA:
        try:
            device = cuda.get_current_device()
            print(f"✓ GPU DETECTED: {device.name}")
            print(f"  Compute Capability: {device.compute_capability}")
            print(f"  Max Threads/Block: {device.MAX_THREADS_PER_BLOCK}")
            print()
        except:
            print("⚠️  CUDA available but device not found - using CPU")
            print()
    else:
        print("⚠️  CUDA not available - CPU mode")
        print()
    
    print(f"Input Data:")
    print(f"  Section 2: {SECTION2[:60]}... ({len(SECTION2)} chars)")
    print(f"  Section 3: {SECTION3} ({len(SECTION3)} chars)")
    print(f"  Custom Alphabet: {CUSTOM_ALPHABET}")
    print()
    
    # Generate permutations
    base58_subset = list(BASE58[:10])  # First 10 Base58 chars for testing
    total_perms = 3628800  # 10!
    
    print(f"Search Space:")
    print(f"  Total Permutations: {total_perms:,}")
    print(f"  Base58 Subset: {base58_subset}")
    print()
    
    valid_results = []
    tested = 0
    start_time = time.time()
    last_print = start_time
    
    print("Starting permutation testing...\n")
    
    for perm_idx, perm in enumerate(itertools.permutations(base58_subset)):
        tested += 1
        result = test_permutation(perm)
        
        # Check for valid results
        if result['k1_valid'] or result['k2_valid']:
            elapsed = time.time() - start_time
            print(f"\n{'🎉'*40}")
            print(f"✅ FOUND VALID RESULT #{len(valid_results)+1}")
            print(f"{'🎉'*40}")
            print(f"  Permutation Index: {perm_idx:,}")
            print(f"  Mapping: {result['mapping']}")
            print(f"  k1: {result['k1']} (Valid: {result['k1_valid']})")
            print(f"  k2: {result['k2']} (Valid: {result['k2_valid']})")
            print(f"  Time to find: {elapsed:.1f} seconds")
            print()
            
            valid_results.append(result)
            
            # Early exit if we found complete solution
            if result['k1_valid'] and result['k2_valid']:
                print(f"{'🎉'*40}")
                print(f"🏆 COMPLETE SOLUTION FOUND! 🏆")
                print(f"{'🎉'*40}\n")
                return valid_results
        
        # Progress update every 5 seconds
        current_time = time.time()
        if current_time - last_print > 5:
            elapsed = current_time - start_time
            rate = tested / elapsed
            remaining = (total_perms - tested) / rate if rate > 0 else 0
            pct = 100 * tested / total_perms
            
            print(f"Progress: {tested:,}/{total_perms:,} ({pct:.2f}%) "
                  f"| {rate:.0f} perms/sec "
                  f"| ETA: {remaining:.0f}s ({remaining/3600:.1f}h)",
                  end='\r', flush=True)
            last_print = current_time
    
    # Final summary
    elapsed = time.time() - start_time
    rate = tested / elapsed if elapsed > 0 else 0
    
    print(f"\n\n{'='*80}")
    print(f"SEARCH COMPLETE")
    print(f"{'='*80}")
    print(f"Total permutations tested: {tested:,}")
    print(f"Time elapsed: {elapsed:.1f} seconds")
    print(f"Rate: {rate:.0f} permutations/second")
    print(f"Results found: {len(valid_results)}")
    print()
    
    if valid_results:
        print(f"✅ VALID RESULTS:\n")
        for i, result in enumerate(valid_results):
            print(f"Result {i+1}:")
            print(f"  Mapping: {result['mapping']}")
            if result['k1_valid']:
                print(f"  ✅ k1 (VALID): {result['k1']}")
            else:
                print(f"  ❌ k1: {result['k1']}")
            
            if result['k2_valid']:
                print(f"  ✅ k2 (VALID): {result['k2']}")
            else:
                print(f"  ❌ k2: {result['k2']}")
            print()
    else:
        print(f"❌ NO VALID WIFs FOUND")
        print(f"\nPossible explanations:")
        print(f"  1. The encoding is not a simple character substitution")
        print(f"  2. Multi-step encoding process is needed")
        print(f"  3. External key/password is required")
        print(f"  4. Check the puzzle documentation for hints")
    
    return valid_results


# ============================================================================
# MAIN EXECUTION
# ============================================================================

def main():
    """Main entry point"""
    try:
        results = brute_force_search()
        
        if results:
            print("\n" + "="*80)
            print("NEXT STEPS:")
            print("="*80)
            print("\n1. Verify the keys are valid:")
            print(f"   - k1 should be 51 chars starting with '5'")
            print(f"   - k2 should be 52 chars starting with 'K' or 'L'")
            print(f"   - Both must have valid Base58Check checksums\n")
            
            print("2. Combine the keys:")
            print(f"   secp256k1_order = 0xFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141")
            print(f"   final_key = (k1_int + k2_int) % secp256k1_order\n")
            
            print("3. Import to Bitcoin wallet:")
            print(f"   - Bitcoin Core: importprivkey <final_wif>")
            print(f"   - Electrum: Import private key")
            print(f"   - Sweep address: 1GSMG1JC9wtdSwfwApgj2xcmJPAwx7prBe\n")
            
            print("4. Claim 2.5 BTC! 🎉\n")
        
        return 0 if results else 1
        
    except KeyboardInterrupt:
        print("\n\n⚠️  Search interrupted by user")
        return 2
    except Exception as e:
        print(f"\n❌ Error: {e}")
        import traceback
        traceback.print_exc()
        return 3


if __name__ == "__main__":
    sys.exit(main())

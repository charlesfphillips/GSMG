#!/bin/bash
# 🔥 QUICK START: GPU Brute Force for P1000
# Installation and execution in 3 minutes

echo ""
echo "=============================================================================="
echo "🔥 GSMG 5 BTC PUZZLE - GPU BRUTE FORCE QUICK START"
echo "=============================================================================="
echo ""

# Step 1: Check NVIDIA GPU
echo "STEP 1: Checking NVIDIA GPU..."
if ! command -v nvidia-smi &> /dev/null; then
    echo "❌ nvidia-smi not found!"
    echo "   Install NVIDIA drivers from: https://www.nvidia.com/Download/driverDetails.aspx"
    exit 1
fi

nvidia-smi
echo ""

# Step 2: Check Python
echo "STEP 2: Checking Python..."
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 not found!"
    echo "   Install: sudo apt-get install python3 python3-pip"
    exit 1
fi

PYTHON_VERSION=$(python3 --version)
echo "✓ Found: $PYTHON_VERSION"
echo ""

# Step 3: Install dependencies
echo "STEP 3: Installing Python dependencies..."
echo "   - numba (GPU JIT compilation)"
echo "   - numpy (numerical computing)"
echo ""

pip install --upgrade pip 2>&1 | grep -v "already satisfied" || true
pip install numba numpy 2>&1 | tail -3

echo ""

# Step 4: Verify CUDA setup
echo "STEP 4: Verifying CUDA setup..."
python3 << 'PYEOF'
try:
    from numba import cuda
    device = cuda.get_current_device()
    print(f"✓ CUDA available: {device.name}")
    print(f"  Compute Capability: {device.compute_capability}")
    print(f"  Max Threads/Block: {device.MAX_THREADS_PER_BLOCK}")
except Exception as e:
    print(f"⚠️  Warning: {e}")
    print("   CUDA will be simulated - expecting slower performance")
PYEOF

echo ""

# Step 5: Run brute force
echo "=============================================================================="
echo "STEP 5: Starting GPU Brute Force!"
echo "=============================================================================="
echo ""
echo "This will test 3,628,800 permutations looking for valid WIF keys."
echo "Expected time on P1000:"
echo "  - With CUDA: 10-30 seconds"
echo "  - Without CUDA (CPU): 2-5 minutes"
echo ""
echo "Press Ctrl+C to stop anytime"
echo ""
echo "=============================================================================="
echo ""

# Run the brute force
python3 gpu_brute_force_final.py

EXIT_CODE=$?

echo ""
echo "=============================================================================="
if [ $EXIT_CODE -eq 0 ]; then
    echo "✅ Brute force completed successfully!"
    echo ""
    echo "If results were found:"
    echo "  1. Verify k1 and k2 are valid WIFs"
    echo "  2. Combine them: (k1_int + k2_int) % secp256k1_order"
    echo "  3. Convert to WIF and import to Bitcoin wallet"
    echo "  4. Sweep the address: 1GSMG1JC9wtdSwfwApgj2xcmJPAwx7prBe"
    echo "  5. Claim 2.5 BTC! 🎉"
else
    echo "⚠️  Brute force completed without finding valid WIFs"
    echo ""
    echo "Possible reasons:"
    echo "  1. The encoding scheme is different than expected"
    echo "  2. Additional decryption steps are needed"
    echo "  3. Check the puzzle documentation"
fi
echo "=============================================================================="
echo ""

exit $EXIT_CODE

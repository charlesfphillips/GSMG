#!/bin/bash
# 🚀 GPU BRUTE FORCE SETUP GUIDE
# ==============================
# For NVIDIA Tesla P1000 GPU
# Installation, verification, and execution

echo "=========================================="
echo "🚀 GSMG GPU BRUTE FORCE SETUP"
echo "=========================================="
echo ""

# ============================================================================
# STEP 1: VERIFY NVIDIA GPU
# ============================================================================

echo "STEP 1: Checking NVIDIA GPU..."
echo ""

if ! command -v nvidia-smi &> /dev/null; then
    echo "❌ nvidia-smi not found!"
    echo "   Install NVIDIA drivers: https://developer.nvidia.com/cuda-downloads"
    exit 1
fi

echo "✓ NVIDIA drivers found"
nvidia-smi
echo ""

# ============================================================================
# STEP 2: INSTALL CUDA TOOLKIT & CUDNN
# ============================================================================

echo "STEP 2: CUDA Toolkit Installation"
echo ""

if ! command -v nvcc &> /dev/null; then
    echo "❌ CUDA Toolkit not installed"
    echo ""
    echo "Installation instructions:"
    echo "1. Download from: https://developer.nvidia.com/cuda-downloads"
    echo "2. Select: Linux > x86_64 > Ubuntu > 22.04 (adjust for your OS)"
    echo "3. Follow installation steps"
    echo "4. Add to PATH:"
    echo "   export PATH=/usr/local/cuda/bin:$PATH"
    echo "   export LD_LIBRARY_PATH=/usr/local/cuda/lib64:$LD_LIBRARY_PATH"
    echo ""
else
    echo "✓ CUDA Toolkit installed"
    nvcc --version | head -3
    echo ""
fi

# ============================================================================
# STEP 3: INSTALL PYTHON DEPENDENCIES
# ============================================================================

echo "STEP 3: Installing Python Dependencies"
echo ""

# Check Python version
PYTHON_VERSION=$(python3 --version 2>&1 | awk '{print $2}')
echo "Python version: $PYTHON_VERSION"
echo ""

# Install pip packages
echo "Installing packages..."
echo "  - numba (JIT compilation and CUDA support)"
echo "  - numpy (numerical computing)"
echo "  - pandas (optional, for result analysis)"
echo ""

pip install --upgrade pip setuptools wheel

# Install numba with CUDA support
echo "Installing Numba with CUDA support..."
pip install numba numpy

# For CUDA 11.x
#pip install numba --prefer-binary
# For CUDA 12.x
#pip install numba

echo ""
echo "✓ Dependencies installed"
echo ""

# ============================================================================
# STEP 4: VERIFY NUMBA CUDA
# ============================================================================

echo "STEP 4: Verifying Numba CUDA Support"
echo ""

python3 << 'PYEOF'
import numba
from numba import cuda

try:
    # Check CUDA availability
    cuda.test()
    print("✓ CUDA is available to Numba")
    
    # Get device info
    device = cuda.get_current_device()
    print(f"✓ GPU Device: {device.name}")
    print(f"  Compute Capability: {device.compute_capability}")
    print(f"  Max Threads per Block: {device.MAX_THREADS_PER_BLOCK}")
    print(f"  Total Memory: {device.total_memory / 1e9:.2f} GB")
    
except Exception as e:
    print(f"✗ CUDA not available: {e}")
    print("  Make sure CUDA toolkit is installed and in PATH")

PYEOF

echo ""

# ============================================================================
# STEP 5: DOWNLOAD BRUTE FORCE SCRIPTS
# ============================================================================

echo "STEP 5: Setting Up Brute Force Scripts"
echo ""

# Files should already be downloaded
# Check for them:
if [ -f "gpu_brute_force_k1_k2.py" ]; then
    echo "✓ gpu_brute_force_k1_k2.py found"
else
    echo "⚠ gpu_brute_force_k1_k2.py not found"
    echo "  Place it in current directory"
fi

if [ -f "optimized_gpu_brute_force.py" ]; then
    echo "✓ optimized_gpu_brute_force.py found"
else
    echo "⚠ optimized_gpu_brute_force.py not found"
    echo "  Place it in current directory"
fi

echo ""

# ============================================================================
# STEP 6: RUN BRUTE FORCE
# ============================================================================

echo "STEP 6: Ready to Run Brute Force!"
echo ""
echo "To start the optimized GPU brute force search:"
echo ""
echo "  python3 optimized_gpu_brute_force.py"
echo ""
echo "Or for the standard version:"
echo ""
echo "  python3 gpu_brute_force_k1_k2.py"
echo ""

echo "=========================================="
echo "Expected Performance:"
echo "=========================================="
echo ""
echo "P1000 GPU:"
echo "  - Smart search (80K perms): ~0.01-0.1 seconds"
echo "  - Full search (3.6M perms): ~0.1-1 second"
echo "  - Rate: 50-100 million permutations/second"
echo ""
echo "CPU (i7/Ryzen equivalent):"
echo "  - Smart search (80K perms): ~0.1-0.5 seconds"
echo "  - Full search (3.6M perms): ~10-30 seconds"
echo "  - Rate: 100K-300K permutations/second"
echo ""
echo "GPU provides ~500x speedup on brute force!"
echo ""

echo "=========================================="
echo "✓ Setup Complete!"
echo "=========================================="
echo ""

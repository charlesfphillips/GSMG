;!function(){try { var e="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof global?global:"undefined"!=typeof window?window:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&((e._debugIds|| (e._debugIds={}))[n]="b812a17d-f0e8-e5bc-5003-8b5b758a38d1")}catch(e){}}();
(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,13603,e=>{"use strict";var l=e.i(843476),i=e.i(647163);e.s(["default",0,({children:e})=>(0,l.jsx)("div",{className:(0,i.cn)("flex flex-col w-full overflow-hidden relative h-dvh"),children:e})])}]);

//# debugId=b812a17d-f0e8-e5bc-5003-8b5b758a38d1
//# sourceMappingURL=55f7d77fcf0f0e9d.js.map